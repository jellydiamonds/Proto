package com.jellydiamonds.android.metier;

public class GemStatusForSale extends GemStatus{

		/**
		 * 
		 */
		private static final long serialVersionUID = 3686868522362429214L;

		public GemStatusForSale()
		{
			this.mCurrentStatus = "forsale";
			this.mCurrentStatusNumber = 3;
		}
}
