package com.jellydiamonds.android.metier;

public class GemStatusTradeInProgress extends GemStatus{

		/**
	 * 
	 */
	private static final long serialVersionUID = 4466307033365404297L;

		/**
		 *  Gem-ID is in TradeInProgress status when a transaction have been started.
		 */
	
		public GemStatusTradeInProgress()
		{
			this.mCurrentStatus = "tradeinprogress";
			this.mCurrentStatusNumber = 4;
		}
}
