/** Automatically generated file. DO NOT MODIFY */
package com.jellydiamonds.android.camera;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}